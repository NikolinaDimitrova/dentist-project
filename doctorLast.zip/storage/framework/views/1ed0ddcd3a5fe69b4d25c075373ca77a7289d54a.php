

<?php $__env->startSection('content'); ?>

<div class="row" id="app">
    <div class="col-xs-12">
        <div class="box">

            <div class="box-header">
                <h3 class="box-title">All Specialists</h3>
                <span>Detailed information</span>
 
            </div>


            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th>Name</th>
                            <th class="nosort">Avatar</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Phone number</th>
                            <th>department</th>
                            <th>edit</th>



                        </tr>

                        <tr>
                            <?php if(count($doctors)>0): ?>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($doctor->name); ?></td>
                            <td><img src="<?php echo e(asset('images')); ?>/<?php echo e($doctor->image); ?>" width="100" alt=""></td>
                            <td><?php echo e($doctor->email); ?></td>
                            <td><?php echo e($doctor->address); ?><i class="ik ik-eye table-actions "></i> </td>
                            <td><?php echo e($doctor->phone_number); ?></td>
                            <td><?php echo e($doctor->department); ?></td>
                            <td>
                                <div class="table-actions">
                                    <a href="<?php echo e(route('doctor.show',[$doctor->id])); ?>"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('doctor.edit',[$doctor->id])); ?>"><i class="far fa-edit"></i></a>
                                    <a href="#"> 
                                     <form class="forms-sample" action="<?php echo e(route('doctor.destroy',[$doctor->id])); ?>"  
                                     method="post"><?php echo csrf_field(); ?>
                                     <?php echo method_field('DELETE'); ?> 
                                     <button class="text-red-500 pr-3" type="submit"><i class="far fa-trash-alt"></i>
                     </button>          
                                     </form> </a>
                                </div>
                            </td>
                        </tr>
                   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                        <td>No doctors to display</td>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\md\Desktop\doctorsMe\doctors\resources\views/admin/doctor/index.blade.php ENDPATH**/ ?>