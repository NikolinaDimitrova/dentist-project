
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
             
              <div class="card-header" >
       
                     Appointment (<?php echo e($patients->count()); ?>)
                 </div>

                <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Photo</th>
                          <th scope="col">Date</th>
                          <th scope="col">User</th>
                          <th scope="col">Email</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Gender</th>

                          <th scope="col">Time</th>
                          <th scope="col">Doctor</th>
                          <th scope="col">Status</th>
                          <th scope="col">Prescription</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <th scope="row"><?php echo e($key+1); ?></th>
                          <td><img src="/profile/<?php echo e($patient->user->image); ?>" width="80" style="border-radius: 50%;">
                          </td>
                          <td>
                                             
</td>
                          <td><?php echo e($patient->user->name); ?></td>
                          <td><?php echo e($patient->user->email); ?></td>
                          <td><?php echo e($patient->user->phone_number); ?></td>
                          <td><?php echo e($patient->user->gender); ?></td>
                          <td><?php echo e($patient->time); ?></td>
                          <td><?php echo e($patient->doctor->name); ?></td>
                          <td>
                            <?php if($patient->status==1): ?>
                             checked
                             <?php endif; ?>
                          </td>
                          <td>
                              <!-- Button trigger modal -->
              
                   <a href="<?php echo e(route('prescription.show',[$patient->user_id,$patient->date])); ?>" class="btn btn-secondary">View prescription</a>
                  

                               
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td>There is no any appointments !</td>
                        <?php endif; ?>
                       
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\md\Desktop\doctorsMe\doctors\resources\views/prescription/all.blade.php ENDPATH**/ ?>