

<?php $__env->startSection('content'); ?>

<div class="page-header">
<div class="row align-items-end">
    <div class="col-lg-8">
        <div class="page-header-title">
            <i class="ik ik-inbox bg-blue"></i>
            <div class="d-inline">
                <h5>Departments</h5>
                <span>list of all departments</span>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <nav class="breadcrumb-container" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="../index.html"><i class="ik ik-home"></i></a>
                </li>
                <li class="breadcrumb-item">
                    <a href="#">Department</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Index</li>
            </ol>
        </nav>
    </div>
</div>
</div>


<div class="row">
<div class="col-md-12">
       <?php if(Session::has('message')): ?>
            <div class="alert bg-success alert-success text-white" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
    <div class="card">
        <div class="card-header"><h3>Data Table</h3>

        </div>
        <div class="card-body">
            <table id="data_table" class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Name</th>
                        
                        <th class="nosort">&nbsp;</th>
                        <th class="nosort">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($departments)>0): ?>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($department->department); ?></td>
                        
                        <td>
                            <div class="table-actions">
                                
                                <a href="<?php echo e(route('department.edit',[$department->id])); ?>"><i class="far fa-edit"></i></a>
                                
                                
                                <form action="<?php echo e(route('department.destroy',[$department->id])); ?>" method="post"><?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"><i class="far fa-trash-alt"></i></button>
                                    
                                </form>

                            </div>
                        </td>
                        <td>x</td>

                    </tr>
           
                  



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    <?php else: ?> 
                    <td>No departments to display</td>
                    <?php endif; ?>
                
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\md\Desktop\doctorsMe\doctors\resources\views/admin/department/index.blade.php ENDPATH**/ ?>