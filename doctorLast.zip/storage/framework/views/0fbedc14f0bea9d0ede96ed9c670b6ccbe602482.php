

<?php $__env->startSection('content'); ?>
<div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-edit bg-blue"></i>
                        <div class="d-inline">
                            <h5>Edit Dentist Information</h5>
                            <span> </span>
                        </div>
                    </div>
                </div>
        <div class="col-lg-4">
            <nav class="breadcrumb-container" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="../index.html"><i class="ik ik-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dentists</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add</li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<div class="row justify-content-center">
<div class="col-md-10">
<p>
            <img src="<?php echo e(asset('images')); ?>/<?php echo e($doctor->image); ?>" width="200" alt="">
        </p>
        <p class="badge badge-pill badge-dark">
            Role:<?php echo e($doctor->role->name); ?>

        </p>
        <p>Name:<?php echo e($doctor->name); ?></p>
        <p>Email:<?php echo e($doctor->email); ?></p>
        <p>Address:<?php echo e($doctor->address); ?></p>
        <p>Phone:<?php echo e($doctor->phone_number); ?></p>
        <p>Department:<?php echo e($doctor->department); ?></p>
        <p>Education:<?php echo e($doctor->education); ?></p>
        <p>Description:<?php echo e($doctor->description); ?></p>


      </div>
      <div >
        
        <a href="<?php echo e(route('doctor.index')); ?>" class="btn btn-primary">Close</a>
       
      </div>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\md\Desktop\doctorsMe\doctors\resources\views/admin/doctor/show.blade.php ENDPATH**/ ?>