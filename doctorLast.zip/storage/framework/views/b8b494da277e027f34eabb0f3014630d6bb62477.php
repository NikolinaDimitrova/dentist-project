Dear <?php echo e($mailData['name']); ?>,
<p>Thank you for booking your appointment with Glenroy Medical Center</p>
<p>The details of your appointment are below:</p>
Time & Date: <?php echo e($mailData['time']); ?>, <?php echo e($mailData['date']); ?><br>
with:Dr. <?php echo e($mailData['doctorName']); ?><br>

Where: 1post office,Maldives
Contact:(044)9348383<?php /**PATH C:\Users\md\Desktop\doctorsMe\doctors\resources\views/email/appointment.blade.php ENDPATH**/ ?>