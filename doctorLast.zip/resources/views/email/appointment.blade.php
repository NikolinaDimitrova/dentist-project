Dear {{$mailData['name']}},
<p>Thank you for booking your appointment with Glenroy Medical Center</p>
<p>The details of your appointment are below:</p>
Time & Date: {{$mailData['time']}}, {{$mailData['date']}}<br>
with:Dr. {{$mailData['doctorName']}}<br>

Where: 1post office,Maldives
Contact:(044)9348383